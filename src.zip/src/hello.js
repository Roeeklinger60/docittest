const {  Input  } = antd;

ReactDOM.render(<Input placeholder="Basic usage" />, mountNode);
